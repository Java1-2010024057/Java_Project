package Sample_0509;

public class InnerClassTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OuterClass outer = new OuterClass();

	}

}
