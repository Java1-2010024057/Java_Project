package Sample_0509;

public class Eagle extends Animal {
	private int wings = 2;
	void fly() {
		System.out.println("fly()�� ȣ��Ǿ���");
	}

}
