package Sample_0509;

public class AminalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lion lion = new Lion();
		lion.eat();
		lion.sleep();
		lion.roar();
		
		Eagle eagle = new Eagle();
		eagle.eat();
		eagle.sleep();
		eagle.fly();
		
		lion.setPicture("Good picture");
	}

}
