package �����߻�;
public class MyFrameTest {
	public static void main(String args[]) {
		MyFrame f = new MyFrame();
	}
}
