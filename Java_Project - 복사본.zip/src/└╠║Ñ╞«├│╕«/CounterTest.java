package �̺�Ʈó��;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

// �ҽ��� �Է��ϰ� Ctrl+Shift+O�� ������ �ʿ��� ������ �����Ѵ�. 

class MyCounter extends JFrame implements ActionListener {
	private JLabel label, label1;
	private JButton button/*, button1*/;
	private int count = 0;

	public MyCounter() {
		JPanel panel = new JPanel();
		label = new JLabel("Counter");
		panel.add(label);

		label1 = new JLabel("" + count);
		label1.setFont(new Font("Serif", 	// ���̺��� ��Ʈ�� �����Ѵ�. 
			Font.BOLD | Font.ITALIC, 100)); 

		panel.add(label1);

		button = new JButton("ī���� ����");
		panel.add(button);
		button.addActionListener(this);
/*
		button1 = new JButton("ī���� �ʱ�ȭ");
		panel.add(button1);
		button1.addActionListener(this);*/
		
		add(panel);
		setSize(300, 200);
		setTitle("My Counter");

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		/*if(event.getSource()==button){*/
		count++;
		label1.setText(count + "");}
		/*else if(event.getSource()==button1){
		count=0;
		label1.setText(count + "");}
	}*/
	
	
}

public class CounterTest {
	public static void main(String[] args) {
		new MyCounter();
	}
}