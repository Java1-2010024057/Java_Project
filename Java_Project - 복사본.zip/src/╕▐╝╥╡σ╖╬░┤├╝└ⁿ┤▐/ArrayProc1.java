package �޼ҵ�ΰ�ü����;

public class ArrayProc1 {

	void inc(int[] array){
		for (int i =0; i<array.length; i++)
			array[i]=array[i]+1;
	}
}
