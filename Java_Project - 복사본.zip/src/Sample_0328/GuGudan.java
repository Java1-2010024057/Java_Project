package Sample_0328;

public class GuGudan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=9;i++){
			for(int j=2;j<=9;j++){
				System.out.print(j+"*"+i+"="+(i*j)+"\t");
			}	
			System.out.println(" ");
		}
		
	}

}
