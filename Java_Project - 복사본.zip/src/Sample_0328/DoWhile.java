package Sample_0328;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 10;
		do {
			
			System.out.println("i�� ��: "+i);
			i++;
		}while(i<12);
		System.out.println(i);
	}
	
}
