package ������;

public class sangsungjatest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sangsungja obj1 = new sangsungja(100);
		sangsungja obj2 = new sangsungja(200);
		//sangsungja1 obj1 = new sangsungja1() -> 1 ���
		System.out.println("��ü 1�� counter = " + obj1.counter);
		System.out.println("��ü 2�� counter = " + obj2.counter);
	}

}
