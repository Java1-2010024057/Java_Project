package ������;

public class TelevisionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Television myTv ;
		myTv = new Television(7, 10, true); //������ȣ��
		myTv.print();
		Television yourTv= new Television(121, 20, true);
		yourTv.print();
	}
}
