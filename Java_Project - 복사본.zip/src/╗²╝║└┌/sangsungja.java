package ������;

class sangsungja {
	int counter;
	
	sangsungja(int value){
		counter=value;
	}
	
	/*
	 sangsungja1(){ 
		counter=1;
	}
	*/
}
