package Sample_0425;

public class TelevisionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Television myTv = new Television(7, 10, true); //������ȣ��
		myTv.print();
		Television yourTv= new Television(11, 20, true);
		yourTv.print();
	}
}
