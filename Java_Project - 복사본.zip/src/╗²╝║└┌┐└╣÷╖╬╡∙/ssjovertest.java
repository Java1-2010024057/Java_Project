package �����ڿ����ε�;

public class ssjovertest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ssjover obj1= new ssjover();
		System.out.println(obj1);
		
		ssjover obj2= new ssjover(111, "kim", 25);
		System.out.println(obj2);
	}

}
