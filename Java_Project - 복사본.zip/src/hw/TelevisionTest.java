package hw;

public class TelevisionTest {
	public static void main(String[] args) {
	      // TODO Auto-generated method stub
	         class Television {
	               int channel;
	               int volume;
	               boolean onOff;
	            }
	      Television tv= new Television();
	      tv.channel = 7;
	      tv.volume = 9;
	      tv.onOff = true;
	      System.out.println("�ڷ������� ä���� " + tv.channel + "�̰� ������ "
	         + tv.volume + "�Դϴ�.");
	   }
}
