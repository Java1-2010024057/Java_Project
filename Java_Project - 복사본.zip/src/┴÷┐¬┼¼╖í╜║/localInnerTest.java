package ����Ŭ����;

public class localInnerTest {
	public static void main(String args[]){
			localInner obj=new localInner();
			obj.display();
		}
	}
