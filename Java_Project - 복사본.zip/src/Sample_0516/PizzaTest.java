package Sample_0516;

public class PizzaTest {

	public static void main(String[] args) {
		Pizza f = new Pizza();
	}

}
